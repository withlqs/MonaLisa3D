程序里面有输入输出文件的路径
先运行trytry（trytry_exe）生成output1.jpg
再运行hand（hand_exe）生成right_final.jpg(终版)


实例可执行程序（trytry_exe/hand_exe）

trytry_exe
输入路径：/Users/moyu/Desktop/trytry/right.jpg
输出路径：/Users/moyu/Desktop/trytry/output1.jpg

hand_exe
输入路径：/Users/moyu/Desktop/trytry/output1.jpg
输出路径：/Users/moyu/Desktop/trytry/right_final.jpg