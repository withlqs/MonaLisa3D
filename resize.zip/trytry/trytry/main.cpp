//
//  main.cpp
//  trytry
//
//  Created by 莫与 on 2018/4/3.
//  Copyright © 2018年 莫与. All rights reserved.
//
/*
#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
*/
#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
#include <stdio.h>

#include <opencv2/opencv.hpp>

#include <opencv2/imgproc/imgproc.hpp>
using namespace cv;
IplImage* src;
IplImage* dst;
IplImage* aaa;
IplImage* p1;
IplImage* p2;
IplImage* p3;
Mat m1;
Mat m2;
Mat m3;
Mat ans;

cv::Mat mergeRows(cv::Mat A, cv::Mat B)
{
    // cv::CV_ASSERT(A.cols == B.cols&&A.type() == B.type());
    int totalRows = A.rows + B.rows;
    cv::Mat mergedDescriptors(totalRows, A.cols, A.type());
    cv::Mat submat = mergedDescriptors.rowRange(0, A.rows);
    A.copyTo(submat);
    submat = mergedDescriptors.rowRange(A.rows, totalRows);
    B.copyTo(submat);
    return mergedDescriptors;
}


int main()
{
    
    
        src = cvLoadImage("/Users/moyu/Desktop/trytry/right.jpg",1);
        
        //cvNamedWindow("源图像",1);
        //cvShowImage("源图像",src);
    
    double x=0.013;
        cvSetImageROI(src,cvRect(0,0*src->height,src->width,x*src->height));
        p1 = cvCreateImage(cvSize(src->width,x*src->height),
                        IPL_DEPTH_8U,
                        src->nChannels);
        cvCopy(src,p1,0);
        cvResetImageROI(p1);
        //cvShowImage("操作后的图像",p1);
        m1=cvarrToMat(p1);
    
        imshow("缩小",m1);
    
    
        cvSetImageROI(src,cvRect(0,x*src->height,src->width,(1-3*x)*src->height));
        dst = cvCreateImage(cvSize(src->width,(1-3*x)*src->height),
                            IPL_DEPTH_8U,
                            src->nChannels);
        cvCopy(src,dst,0);
        cvResetImageROI(dst);
        p2=dst;
        m2=cvarrToMat(p2);
    
    
        cvSetImageROI(src,cvRect(0,(1-2*x)*src->height,src->width,2*x*src->height));
        p3 = cvCreateImage(cvSize(src->width,2*x*src->height),
                           IPL_DEPTH_8U,
                           src->nChannels);
        cvCopy(src,p3,0);
        cvResetImageROI(p3);
        m3=cvarrToMat(p3);
    
    
     
     
    
        //cv::imwrite(,dst);
        //cvSaveImage("/Users/moyu/Desktop/re1.jpg", dst);
        //resize(temImage,aaa,Size(temImage.cols/2,temImage.rows/2),0,0,INTER_LINEAR);
        //cvNamedWindow("操作后的图像",1);
        //cvShowImage("操作后的图像",dst);
    
        //Mat image = src;
    
    
    
        Mat srcImage = cvarrToMat(p1);
        Mat temImage,dstImage1,dstImage2;
        temImage=srcImage;
        resize(temImage,dstImage1,Size(temImage.cols,temImage.rows/2),0,0,INTER_LINEAR);
        //imshow("缩小",dstImage1);
        //imshow("缩小",m2);
        ans=mergeRows(mergeRows(dstImage1,m2),m3);
    //imshow("缩小",ans);
    cv::imwrite("/Users/moyu/Desktop/trytry/output1.jpg",ans);
       //cvSaveImage("/Users/moyu/Desktop/re1.bmp",dst);
    
    //cv::imwrite("output.bmp",dst);
        //cvDestroyWindow("操作后的图像");
        //cvDestroyWindow("源图像");
    
    cvReleaseImage(&src);
    cvReleaseImage(&dst);
    
    //waitKey();
    return 0;
}
